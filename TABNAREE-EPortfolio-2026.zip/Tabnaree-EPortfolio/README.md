# TABNAREE Education Portfolio

E-Portfolio ส่วนบุคคลสำหรับ **นักวิชาการศึกษา** โดยออกแบบใหม่จากศูนย์ ไม่ผูกกับภาคเรียน ปีการศึกษา PA หรือข้อตกลงตัวชี้วัด

## แนวคิด

- Public Website + Admin หลังบ้านในโปรเจกต์เดียว
- Next.js + TypeScript + Tailwind CSS
- Turso (libSQL) เป็นฐานข้อมูล
- Google Drive เป็นแหล่งเก็บรูปและเอกสาร
- Netlify เป็น Hosting/Serverless runtime
- GitHub เป็นแหล่งเก็บ Source Code
- มี 3 Theme: โทนสีที่ 1, โทนสีที่ 2, Dark Mode

## สิ่งที่มีในระบบ

### Public

- `/` หน้าแรกแบบ Portfolio + ข่าวประชาสัมพันธ์
- `/about` เกี่ยวกับฉัน
- `/works` ผลงาน + Search/Filter
- `/works/[slug]` รายละเอียดผลงาน
- `/self-development` การพัฒนาตนเอง
- `/awards` รางวัลและการยอมรับ
- `/news` ข่าวประชาสัมพันธ์
- `/news/[slug]` รายละเอียดข่าว
- `/contact` ติดต่อ

### Admin

- `/login` Email + Password
- `/admin` Dashboard
- `/admin/works` จัดการผลงาน
- `/admin/news` จัดการข่าว
- `/admin/self-development` จัดการการพัฒนาตนเอง
- `/admin/awards` จัดการรางวัล
- `/admin/media` จัดการสื่อ
- `/admin/profile` แก้ไขโปรไฟล์
- `/admin/settings` Theme + Site Settings

## ผลงาน

ผลงานมีระดับ 4 ระดับ:

- ประเทศ
- จังหวัด
- หน่วยงาน
- อื่น ๆ

ประเภทงานเป็นข้อมูลจากตาราง `work_types` จึงเพิ่มประเภทใหม่ได้โดยไม่แก้ Code

คุณลักษณะเป็น Many-to-Many:

- การครองตน
- การครองคน
- การครองงาน
- จริยธรรม

ไม่มีการเก็บหลายค่าไว้ใน string เดียว

## Google Drive Image

Admin สามารถวาง Google Drive Share URL ได้ เช่น

`https://drive.google.com/file/d/FILE_ID/view?usp=sharing`

ระบบจะ parse File ID แล้วสร้าง URL สำหรับ Preview ให้เอง โดยลอง URL รูปหลักและมี fallback สำหรับ thumbnail หากรูปหลักโหลดไม่ได้

ไฟล์ต้องแชร์เป็น **ทุกคนที่มีลิงก์สามารถดู** ก่อนนำมาใช้บน Public Website

## ติดตั้ง

1. สร้าง Turso database
2. สร้าง token
3. ตั้ง Environment Variables

```text
TURSO_DATABASE_URL=libsql://...
TURSO_AUTH_TOKEN=...
AUTH_SECRET=long-random-secret-at-least-32-chars
NEXT_PUBLIC_SITE_URL=https://portfolio.tabnaree.com
```

4. ติดตั้ง package

```bash
npm install
```

5. สร้าง schema

```bash
npm run db:init
npm run db:seed
```

6. สร้าง Admin ครั้งแรก

ให้ใช้ SQL นี้กับ Turso โดยสร้าง bcrypt hash ด้วยวิธีที่ปลอดภัย หรือเพิ่ม setup screen ภายหลัง:

```sql
INSERT INTO users(email,password_hash) VALUES('your@email.com','BCRYPT_HASH');
```

แนะนำให้ใช้ script/CLI ภายในเครื่องเพื่อสร้าง hash ไม่ควรใส่รหัสผ่านจริงลงใน GitHub

7. รัน

```bash
npm run dev
```

## Netlify

เชื่อม GitHub repository กับ Netlify แล้วตั้ง Environment Variables เดียวกับด้านบน จากนั้น Deploy

Netlify รองรับ Next.js App Router และจัดการ runtime สำหรับ SSR, Route Handlers และ Server Actions ผ่าน OpenNext adapter โดยอัตโนมัติใน deployment สมัยใหม่

## Domain

ตั้งใจใช้:

`https://portfolio.tabnaree.com`

ใน Netlify ให้เพิ่ม custom domain และสร้าง DNS record ของ `portfolio` ให้ชี้ตามค่าที่ Netlify แนะนำ

## โครงสร้าง

```text
app/
  (public)/       # Public pages
  admin/          # Protected admin
  login/          # Authentication
components/       # Reusable UI
lib/              # DB, auth, media, query helpers
db/               # Schema + seed
scripts/          # DB setup scripts
public/           # Static fallback assets
```

## หลักการสำคัญ

- Public เห็นเฉพาะ `published`
- Admin เห็น draft ด้วย
- ข้อมูลสำคัญใช้ `deleted_at` สำหรับ soft delete
- Password ไม่เก็บ plaintext
- Secrets ไม่ใช้ `NEXT_PUBLIC_`
- Google Drive URL parser อยู่ที่ `lib/media.ts` จุดเดียว
- Theme ใช้ CSS variables ไม่กระจายค่าสีไปตาม component
