'use server'
import {requireAdmin} from '@/lib/auth'; import {run,one} from '@/lib/db'; import {revalidatePath} from 'next/cache'; import {slugifyThai} from '@/lib/format'; import {parseGoogleDriveUrl,googleDriveImageUrl} from '@/lib/media'
export async function toggleWork(id:number,status:'draft'|'published'){await requireAdmin(); await run('UPDATE works SET status=:status,updated_at=CURRENT_TIMESTAMP WHERE id=:id',{':status':status,':id':id}); revalidatePath('/');revalidatePath('/works');revalidatePath('/admin/works')}
export async function deleteWork(id:number){await requireAdmin(); await run('UPDATE works SET deleted_at=CURRENT_TIMESTAMP WHERE id=:id',{':id':id}); revalidatePath('/');revalidatePath('/works');revalidatePath('/admin/works')}
async function saveWorkInternal(form:FormData,id?:number){
  await requireAdmin()
  const title=String(form.get('title')||'').trim()
  const inputSlug=String(form.get('slug')||'').trim()
  const slug=slugifyThai(inputSlug||title)
  const drive=String(form.get('cover_image_url')||'').trim()
  const driveId=parseGoogleDriveUrl(drive)
  const cover=driveId?googleDriveImageUrl(driveId):drive
  const data={':title':title,':slug':slug,':level':String(form.get('work_level')||'อื่น ๆ'),':type':Number(form.get('work_type_id')||0)||null,':role':String(form.get('role')||''),':summary':String(form.get('summary')||''),':content':String(form.get('content')||''),':date':String(form.get('work_date')||'')||null,':location':String(form.get('location')||''),':cover':cover,':video':String(form.get('video_url')||''),':tags':String(form.get('tags')||''),':status':String(form.get('status')||'draft'),':featured':form.get('featured')?'1':'0'}
  let workId=id
  if(id){
    await run(`UPDATE works SET title=:title,slug=:slug,work_level=:level,work_type_id=:type,role=:role,summary=:summary,content=:content,work_date=:date,location=:location,cover_image_url=:cover,video_url=:video,tags=:tags,status=:status,featured=:featured,updated_at=CURRENT_TIMESTAMP WHERE id=:id`,{...data,':id':id})
  }else{
    const result=await run(`INSERT INTO works(title,slug,work_level,work_type_id,role,summary,content,work_date,location,cover_image_url,video_url,tags,status,featured) VALUES(:title,:slug,:level,:type,:role,:summary,:content,:date,:location,:cover,:video,:tags,:status,:featured)`,data)
    workId=Number(result.lastInsertRowid)
  }
  await run('DELETE FROM work_criteria_map WHERE work_id=:id',{':id':workId})
  const criteriaIds=form.getAll('criteria').map(v=>Number(v)).filter(Boolean)
  for(const criteriaId of criteriaIds) await run('INSERT OR IGNORE INTO work_criteria_map(work_id,criteria_id) VALUES(:work,:criteria)',{':work':workId,':criteria':criteriaId})
  revalidatePath('/');revalidatePath('/works');revalidatePath('/admin/works')
}
export async function saveWork(form:FormData){ return saveWorkInternal(form) }
export async function updateWork(id:number,form:FormData){ return saveWorkInternal(form,id) }

export async function addWorkImage(workId:number,form:FormData){
  await requireAdmin(); const raw=String(form.get('url')||'').trim(); const id=parseGoogleDriveUrl(raw); if(!id) return
  await run(`INSERT INTO work_images(work_id,source,original_url,file_id,display_url,caption,alt_text,sort_order,is_cover) VALUES(:work,'google_drive',:url,:id,:display,:caption,:alt,:sort,0)`,{':work':workId,':url':raw,':id':id,':display':googleDriveImageUrl(id),':caption':String(form.get('caption')||''),':alt':String(form.get('alt_text')||''),':sort':Number(form.get('sort_order')||0)})
  revalidatePath(`/admin/works/${workId}/edit`); revalidatePath('/works')
}
export async function deleteWorkImage(id:number,workId:number){await requireAdmin();await run('DELETE FROM work_images WHERE id=:id',{':id':id});revalidatePath(`/admin/works/${workId}/edit`);revalidatePath('/works')}
export async function addWorkFile(workId:number,form:FormData){await requireAdmin();await run(`INSERT INTO work_files(work_id,title,url,file_id,file_type,description,sort_order) VALUES(:work,:title,:url,:file,:type,:desc,:sort)`,{':work':workId,':title':String(form.get('title')||''),':url':String(form.get('url')||''),':file':parseGoogleDriveUrl(String(form.get('url')||''))||'',':type':String(form.get('file_type')||''),':desc':String(form.get('description')||''),':sort':Number(form.get('sort_order')||0)});revalidatePath(`/admin/works/${workId}/edit`);revalidatePath('/works')}
export async function deleteWorkFile(id:number,workId:number){await requireAdmin();await run('DELETE FROM work_files WHERE id=:id',{':id':id});revalidatePath(`/admin/works/${workId}/edit`);revalidatePath('/works')}
