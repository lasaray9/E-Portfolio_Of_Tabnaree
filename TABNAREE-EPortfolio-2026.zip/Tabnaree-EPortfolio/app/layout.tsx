import type { Metadata } from 'next'
import './globals.css'
export const metadata:Metadata={title:'TABNAREE Education Portfolio',description:'Personal E-Portfolio ของนักวิชาการศึกษา'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="th"><body>{children}</body></html>}
