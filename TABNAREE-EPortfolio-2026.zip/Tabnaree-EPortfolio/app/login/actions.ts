'use server'
import {redirect} from 'next/navigation'; import {one,run} from '@/lib/db'; import {createSession,verifyPassword,clearSession} from '@/lib/auth'
export async function login(form:FormData){const email=String(form.get('email')||'').trim().toLowerCase(); const password=String(form.get('password')||''); const user=await one<any>('SELECT * FROM users WHERE email=:email AND is_active=1 LIMIT 1',{':email':email}); if(!user||!(await verifyPassword(password,user.password_hash))) redirect('/login?error=1'); await run('UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=:id',{':id':user.id}); await createSession(user.id); redirect('/admin')}
export async function logout(){await clearSession(); redirect('/login')}
