import Header from './Header'; import Footer from './Footer'; import {getSettings} from '@/lib/queries'
export default async function PublicShell({children}:{children:React.ReactNode}){const settings=await getSettings().catch(()=>null); const theme=settings?.theme||'theme-1'; return <div data-theme={theme}><Header/>{children}<Footer/></div>}
