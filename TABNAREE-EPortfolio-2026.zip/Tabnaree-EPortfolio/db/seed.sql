INSERT OR IGNORE INTO profiles (id, full_name, display_name, position, organization, bio, introduction)
VALUES (1, 'เทพนรี เชื้อไทย', 'TABNAREE', 'นักวิชาการศึกษา', 'สำนักงานศึกษาธิการจังหวัดอุบลราชธานี',
'นักวิชาการศึกษาที่รวบรวมผลงาน การปฏิบัติงาน และการเรียนรู้ไว้ในพื้นที่เดียว',
'ยินดีต้อนรับสู่ Education Portfolio พื้นที่สำหรับนำเสนอผลงาน โครงการ กิจกรรม งานวิชาการ การพัฒนาตนเอง และการประชาสัมพันธ์ผลงาน');

INSERT OR IGNORE INTO site_settings (id) VALUES (1);

INSERT OR IGNORE INTO work_types (name, sort_order) VALUES
('โครงการ',1),('กิจกรรม',2),('งานคณะกรรมการ/คณะทำงาน',3),('งานประสานงาน',4),('งานวิชาการ',5),('งานพัฒนาระบบ',6),('นวัตกรรม',7),('คู่มือ',8),('สื่อประชาสัมพันธ์',9),('การอบรม',10),('การประชุม',11),('อื่น ๆ',99);

INSERT OR IGNORE INTO work_criteria (name, sort_order) VALUES
('การครองตน',1),('การครองคน',2),('การครองงาน',3),('จริยธรรม',4);
