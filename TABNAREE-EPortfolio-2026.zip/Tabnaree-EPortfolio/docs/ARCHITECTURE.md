# Architecture Notes

โปรเจกต์นี้เป็นการออกแบบใหม่สำหรับนักวิชาการศึกษาโดยเฉพาะ ไม่ใช้ schema วPA ของต้นแบบ

## Core split

- `app/(public)` — public portfolio
- `app/admin` — owner CMS
- `lib/db.ts` — Turso access
- `lib/auth.ts` — session authentication
- `lib/media.ts` — Google Drive URL parsing and media URL generation
- `db/schema.sql` — database source of truth

## Date model

ใช้ `work_date`, `news_date`, `date`, `year` ตามเนื้อหาของรายการ

ไม่มี `academic_year`, `semester`, `PA`, `fiscal_year` หรือ indicator agreement

## Media

Database เก็บ metadata/URL ไม่เก็บ binary media
Google Drive เป็น source of truth สำหรับไฟล์ที่เจ้าของต้องการเก็บเอง
