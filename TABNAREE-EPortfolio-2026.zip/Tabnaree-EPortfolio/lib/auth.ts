import 'server-only'
import bcrypt from 'bcryptjs'
import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { one, run } from './db'

const COOKIE = 'tabnaree_admin_session'
function secret() {
  const value = process.env.AUTH_SECRET
  if (!value || value.length < 32) throw new Error('AUTH_SECRET ต้องมีความยาวอย่างน้อย 32 ตัวอักษร')
  return new TextEncoder().encode(value)
}

export async function hashPassword(password: string) { return bcrypt.hash(password, 12) }
export async function verifyPassword(password: string, hash: string) { return bcrypt.compare(password, hash) }

export async function createSession(userId: number) {
  const token = await new SignJWT({ sub: String(userId), role: 'admin' })
    .setProtectedHeader({ alg: 'HS256' }).setIssuedAt().setExpirationTime('7d').sign(secret())
  const store = await cookies()
  store.set(COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 7 })
}

export async function clearSession() { (await cookies()).delete(COOKIE) }

export async function currentAdmin() {
  const token = (await cookies()).get(COOKIE)?.value
  if (!token) return null
  try {
    const { payload } = await jwtVerify(token, secret())
    const id = Number(payload.sub)
    if (!id) return null
    return await one<{id:number,email:string,role:string}>(`SELECT id,email,role FROM users WHERE id=:id AND is_active=1 LIMIT 1`, { ':id': id })
  } catch { return null }
}

export async function requireAdmin() {
  const admin = await currentAdmin()
  if (!admin) throw new Error('UNAUTHORIZED')
  return admin
}

export async function ensureAdmin(email: string, password: string) {
  const exists = await one<{id:number}>('SELECT id FROM users LIMIT 1')
  if (exists) return false
  const hash = await hashPassword(password)
  await run('INSERT INTO users(email,password_hash) VALUES(:email,:hash)', { ':email': email.toLowerCase(), ':hash': hash })
  return true
}
