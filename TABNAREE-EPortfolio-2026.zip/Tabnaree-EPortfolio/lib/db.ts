import 'server-only'
import { createClient } from '@libsql/client'

let client: ReturnType<typeof createClient> | null = null
export function db() {
  if (client) return client
  const url = process.env.TURSO_DATABASE_URL
  const authToken = process.env.TURSO_AUTH_TOKEN
  if (!url) throw new Error('ยังไม่ได้ตั้ง TURSO_DATABASE_URL')
  client = createClient({ url, authToken })
  return client
}

export async function all<T = Record<string, unknown>>(sql: string, args: Record<string, unknown> = {}) {
  const result = await db().execute({ sql, args })
  return result.rows as unknown as T[]
}
export async function one<T = Record<string, unknown>>(sql: string, args: Record<string, unknown> = {}) {
  const rows = await all<T>(sql, args)
  return rows[0] ?? null
}
export async function run(sql: string, args: Record<string, unknown> = {}) {
  return db().execute({ sql, args })
}
