const months = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.']
export function thaiDate(value?: string | null) {
  if (!value) return '—'
  const d = new Date(`${String(value).slice(0,10)}T00:00:00`)
  if (Number.isNaN(d.getTime())) return '—'
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()+543}`
}
export function excerpt(text: string, length=150) {
  const clean = text.replace(/<[^>]+>/g,'').replace(/\s+/g,' ').trim()
  return clean.length <= length ? clean : `${clean.slice(0,length).trimEnd()}…`
}
export function slugifyThai(input: string) {
  const s = input.toLowerCase().trim().replace(/[^\p{L}\p{N}\s-]/gu,'').replace(/\s+/g,'-').replace(/-+/g,'-')
  return s || `item-${Date.now()}`
}
