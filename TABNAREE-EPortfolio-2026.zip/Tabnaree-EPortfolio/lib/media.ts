export const PLACEHOLDER = '/placeholder.svg'

export function parseGoogleDriveUrl(input: string): string | null {
  const value = String(input || '').trim()
  if (!value) return null
  if (/^[A-Za-z0-9_-]{20,100}$/.test(value)) return value
  const patterns = [
    /\/d\/([A-Za-z0-9_-]{20,100})/,
    /[?&]id=([A-Za-z0-9_-]{20,100})/,
    /\/folders\/([A-Za-z0-9_-]{20,100})/
  ]
  for (const pattern of patterns) {
    const match = value.match(pattern)
    if (match?.[1]) return match[1]
  }
  return null
}

export function googleDriveImageUrl(fileId: string, width = 1600) {
  return `https://lh3.googleusercontent.com/d/${fileId}=w${width}`
}

export function googleDriveFallbackImageUrl(fileId: string) {
  return `https://drive.google.com/thumbnail?id=${encodeURIComponent(fileId)}&sz=w1600`
}

export function googleDriveViewUrl(fileId: string) {
  return `https://drive.google.com/file/d/${fileId}/view`
}

export function googleDrivePreviewUrl(fileId: string) {
  return `https://drive.google.com/file/d/${fileId}/preview`
}

export function youtubeEmbedUrl(url: string) {
  const value = String(url || '')
  const match = value.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/)
  return match?.[1] ? `https://www.youtube.com/embed/${match[1]}` : null
}

export function normalizeImageUrl(input: string) {
  const id = parseGoogleDriveUrl(input)
  if (!id) return { fileId: '', displayUrl: '', valid: false }
  return { fileId: id, displayUrl: googleDriveImageUrl(id), valid: true }
}
