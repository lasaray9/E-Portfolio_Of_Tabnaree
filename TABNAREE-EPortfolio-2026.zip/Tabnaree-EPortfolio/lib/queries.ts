import { all, one } from './db'

export async function getProfile() { return one<any>('SELECT * FROM profiles WHERE id=1') }
export async function getSettings() { return one<any>('SELECT * FROM site_settings WHERE id=1') }
export async function getCriteria() { return all<any>('SELECT * FROM work_criteria WHERE is_active=1 ORDER BY sort_order,id') }
export async function getWorkTypes() { return all<any>('SELECT * FROM work_types WHERE is_active=1 ORDER BY sort_order,id') }

export async function getWorks(filters: { q?:string; level?:string; type?:string; criteria?:string; year?:string; featured?:string; limit?:number; includeDrafts?:boolean } = {}) {
  const where:string[] = ["w.deleted_at IS NULL"]
  const args:Record<string,unknown> = {}
  if (filters.q) { where.push('(w.title LIKE :q OR w.summary LIKE :q OR w.tags LIKE :q OR wt.name LIKE :q)'); args[':q'] = `%${filters.q}%` }
  if (filters.level) { where.push('w.work_level=:level'); args[':level']=filters.level }
  if (filters.type) { where.push('w.work_type_id=:type'); args[':type']=Number(filters.type) }
  if (filters.year) { where.push("substr(w.work_date,1,4)=:year"); args[':year']=String(Number(filters.year)-543) }
  if (filters.featured === '1') where.push('w.featured=1')
  if (filters.criteria) { where.push('EXISTS (SELECT 1 FROM work_criteria_map m WHERE m.work_id=w.id AND m.criteria_id=:criteria)'); args[':criteria']=Number(filters.criteria) }
  if (!filters.includeDrafts) where.push("w.status='published'")
  const limit = Math.min(Math.max(filters.limit ?? 100,1),200)
  return all<any>(`SELECT w.*, wt.name work_type_name FROM works w LEFT JOIN work_types wt ON wt.id=w.work_type_id WHERE ${where.join(' AND ')} ORDER BY w.featured DESC, w.work_date DESC, w.id DESC LIMIT ${limit}`, args)
}

export async function getWorkBySlug(slug:string) {
  const work = await one<any>(`SELECT w.*, wt.name work_type_name FROM works w LEFT JOIN work_types wt ON wt.id=w.work_type_id WHERE w.slug=:slug AND w.status='published' AND w.deleted_at IS NULL LIMIT 1`, {':slug':slug})
  if (!work) return null
  const criteria = await all<any>('SELECT c.* FROM work_criteria c JOIN work_criteria_map m ON m.criteria_id=c.id WHERE m.work_id=:id ORDER BY c.sort_order', {':id':work.id})
  const images = await all<any>('SELECT * FROM work_images WHERE work_id=:id ORDER BY is_cover DESC, sort_order,id', {':id':work.id})
  const files = await all<any>('SELECT * FROM work_files WHERE work_id=:id ORDER BY sort_order,id', {':id':work.id})
  const videos = await all<any>('SELECT * FROM work_videos WHERE work_id=:id ORDER BY sort_order,id', {':id':work.id})
  return {...work, criteria, images, files, videos}
}

export async function getLatestNews(limit=6) { return all<any>(`SELECT * FROM news WHERE status='published' AND deleted_at IS NULL ORDER BY news_date DESC,id DESC LIMIT ${limit}`) }
export async function getNewsBySlug(slug:string) { return one<any>(`SELECT * FROM news WHERE slug=:slug AND status='published' AND deleted_at IS NULL`,{':slug':slug}) }
export async function getSelfDevelopments(limit=6) { return all<any>(`SELECT * FROM self_developments WHERE status='published' AND deleted_at IS NULL ORDER BY date DESC,id DESC LIMIT ${limit}`) }
export async function getAwards(limit=6) { return all<any>(`SELECT * FROM awards WHERE status='published' AND deleted_at IS NULL ORDER BY year DESC,id DESC LIMIT ${limit}`) }

export async function getStats() {
  const levels = await all<any>(`SELECT work_level, COUNT(*) count FROM works WHERE status='published' AND deleted_at IS NULL GROUP BY work_level`)
  const criteria = await all<any>(`SELECT c.id,c.name,COUNT(m.work_id) count FROM work_criteria c LEFT JOIN work_criteria_map m ON m.criteria_id=c.id LEFT JOIN works w ON w.id=m.work_id AND w.status='published' AND w.deleted_at IS NULL WHERE c.is_active=1 GROUP BY c.id,c.name,c.sort_order ORDER BY c.sort_order`)
  const total = await one<any>(`SELECT COUNT(*) count FROM works WHERE status='published' AND deleted_at IS NULL`)
  const map = Object.fromEntries(levels.map(x=>[x.work_level,Number(x.count)]))
  return { total:Number(total?.count||0), levels:{ประเทศ:map['ประเทศ']||0,จังหวัด:map['จังหวัด']||0,หน่วยงาน:map['หน่วยงาน']||0,'อื่น ๆ':map['อื่น ๆ']||0}, criteria }
}
