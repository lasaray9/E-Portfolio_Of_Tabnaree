export type WorkLevel = 'ประเทศ'|'จังหวัด'|'หน่วยงาน'|'อื่น ๆ'
export type Status = 'draft'|'published'
export interface WorkRow { id:number; title:string; slug:string; work_level:WorkLevel; work_type_name:string|null; role:string; summary:string; content:string; work_date:string|null; location:string; cover_image_url:string; video_url:string; tags:string; status:Status; featured:number; view_count:number }
export interface Criteria { id:number; name:string; description:string; sort_order:number }
