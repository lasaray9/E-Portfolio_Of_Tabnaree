import { NextRequest, NextResponse } from 'next/server'
import { jwtVerify } from 'jose'
const COOKIE='tabnaree_admin_session'
export async function middleware(req:NextRequest){
  if(!req.nextUrl.pathname.startsWith('/admin') || req.nextUrl.pathname==='/admin/login') return NextResponse.next()
  const token=req.cookies.get(COOKIE)?.value
  if(!token) return NextResponse.redirect(new URL('/login',req.url))
  try{
    const secret=process.env.AUTH_SECRET
    if(!secret) throw new Error('missing secret')
    await jwtVerify(token,new TextEncoder().encode(secret))
    return NextResponse.next()
  }catch{return NextResponse.redirect(new URL('/login',req.url))}
}
export const config={matcher:['/admin/:path*']}
