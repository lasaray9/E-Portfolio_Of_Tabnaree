import fs from 'node:fs'; import {createClient} from '@libsql/client';
const url=process.env.TURSO_DATABASE_URL, authToken=process.env.TURSO_AUTH_TOKEN; if(!url){console.error('ตั้ง TURSO_DATABASE_URL ก่อน');process.exit(1)}
const client=createClient({url,authToken}); const sql=fs.readFileSync(new URL('../db/schema.sql',import.meta.url),'utf8'); const statements=sql.split(';').map(x=>x.trim()).filter(Boolean); for(const statement of statements) await client.execute(statement); console.log('Database initialized.')
