import fs from 'node:fs'; import {createClient} from '@libsql/client';
const client=createClient({url:process.env.TURSO_DATABASE_URL,authToken:process.env.TURSO_AUTH_TOKEN}); const sql=fs.readFileSync(new URL('../db/seed.sql',import.meta.url),'utf8'); for(const statement of sql.split(';').map(x=>x.trim()).filter(Boolean)) await client.execute(statement); console.log('Seed complete.')
